#cd calc_discrete_dist
#make clean
#make
#./calc_discrete_dist
#mv all_segments_Ni_gbpd.txt all_segments_Ni_gbcd.txt ../graph_discrete_dist/

#cd
#cd GBTools_Rohrer/graph_discrete_dist
#sed -i '5s/.*/0  1  0  0  0/' input.txt
#make clean
#make
#
## 正确的变量赋值方式，去掉等号两边的空格
#temp_file=$(mktemp)
#./graph_discrete_dist > "$temp_file"
#
## 使用 $() 而非 () 并且正确引用 temp_file 变量
#cmd=$(tail -n 2 "$temp_file" | head -n 1 | sed 's/^For example: //')
#
#echo "执行的命令为：$cmd"
#eval "$cmd"
#rm "$temp_file"
#mv *.tif ../result/gbpd/
#mv *.ps ../result/gbpd/
#mv *.dat ../result/gbpd/


cd
cd GBTools_Rohrer/graph_discrete_dist

sed -i '5s/.*/0  0  0  1  0/' input.txt

declare -a axis=("0,0,1" "0,1,1" "1,1,1" "0,1,2" "1,1,2" "1,2,2" "0,1,3" "1,1,3")

# 进入循环
for m in {0..7}; do
    for n in {1..12}; do
        # 解析 axis 数组的当前元素
		IFS=',' read -r -a current_axis <<< "${axis[m]}"
		
		# 构建新行的内容
		new_sline="axis${current_axis[0]}${current_axis[1]}${current_axis[2]}_angle$((n * 5))"
		sed -i "7s/.*/$new_sline/" input.txt
		new_line=$(printf "%.1f      %.1f      %.1f      %.1f" ${current_axis[0]} ${current_axis[1]} ${current_axis[2]} $((n * 5)))
		sed -i "10s/.*/$new_line/" input.txt
		
		make clean
		make
		# 正确的变量赋值方式，去掉等号两边的空格
		temp_file=$(mktemp)
		./graph_discrete_dist > "$temp_file"
		
		# 使用 $() 而非 () 并且正确引用 temp_file 变量
		cmd=$(tail -n 2 "$temp_file" | head -n 1 | sed 's/^For example: //')
		
		echo "执行的命令为：$cmd"
		eval "$cmd"
		rm "$temp_file"
		
		# 新的基础文件名
		axis_name="${current_axis[0]}${current_axis[1]}${current_axis[2]}" # 构造文件名中的axis部分
		new_filename_tif="axis${axis_name}_angle$((n*5)).tif" # 构造新的文件名
		new_filename_dat="axis${axis_name}_angle$((n*5)).dat" # 构造新的文件名
		new_filename_ps="axis${axis_name}_angle$((n*5)).ps" # 构造新的文件名
		
		tif_file=$(find . -maxdepth 1 -name '*.tif' -print -quit)
		dat_file=$(find . -maxdepth 1 -name '*.dat' -print -quit)
		ps_file=$(find . -maxdepth 1 -name '*.ps' -print -quit)
		
		mv "$tif_file" "../result/gbcd/$new_filename_tif"
		cd
		cd GBTools_Rohrer/graph_discrete_dist
		mv "$dat_file" "../result/gbcd/$new_filename_dat"
		cd
		cd GBTools_Rohrer/graph_discrete_dist
		mv "$ps_file" "../result/gbcd/$new_filename_ps"
    done
done